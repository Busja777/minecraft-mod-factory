scoreboard players operation @s th.n = @s sethome
scoreboard players set @s sethome 0
execute unless score @s th.n matches 1..3 run tellraw @s {"text":"There are homes 1 to 3: /trigger sethome set 2 saves home 2.","color":"red"}
execute unless score @s th.n matches 1..3 run return fail
scoreboard players set @s th.tmp 0
execute if dimension minecraft:overworld run scoreboard players set @s th.tmp 1
execute if dimension minecraft:the_nether run scoreboard players set @s th.tmp 2
execute if dimension minecraft:the_end run scoreboard players set @s th.tmp 3
execute if score @s th.tmp matches 0 run tellraw @s {"text":"Homes can only be set in the Overworld, the Nether and the End.","color":"red"}
execute if score @s th.tmp matches 0 run return fail
execute if score @s th.n matches 1 run scoreboard players operation @s th.dim = @s th.tmp
execute if score @s th.n matches 1 store result score @s th.x run data get entity @s Pos[0]
execute if score @s th.n matches 1 store result score @s th.y run data get entity @s Pos[1]
execute if score @s th.n matches 1 store result score @s th.z run data get entity @s Pos[2]
execute if score @s th.n matches 1 if score @s th.dim matches 1 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Overworld. Type /trigger home to come back."}]}
execute if score @s th.n matches 1 if score @s th.dim matches 2 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Nether. Type /trigger home to come back."}]}
execute if score @s th.n matches 1 if score @s th.dim matches 3 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the End. Type /trigger home to come back."}]}
execute if score @s th.n matches 2 run scoreboard players operation @s th.dim2 = @s th.tmp
execute if score @s th.n matches 2 store result score @s th.x2 run data get entity @s Pos[0]
execute if score @s th.n matches 2 store result score @s th.y2 run data get entity @s Pos[1]
execute if score @s th.n matches 2 store result score @s th.z2 run data get entity @s Pos[2]
execute if score @s th.n matches 2 if score @s th.dim2 matches 1 run tellraw @s {"text":"Home 2 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the Overworld. Type /trigger home set 2 to come back."}]}
execute if score @s th.n matches 2 if score @s th.dim2 matches 2 run tellraw @s {"text":"Home 2 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the Nether. Type /trigger home set 2 to come back."}]}
execute if score @s th.n matches 2 if score @s th.dim2 matches 3 run tellraw @s {"text":"Home 2 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the End. Type /trigger home set 2 to come back."}]}
execute if score @s th.n matches 3 run scoreboard players operation @s th.dim3 = @s th.tmp
execute if score @s th.n matches 3 store result score @s th.x3 run data get entity @s Pos[0]
execute if score @s th.n matches 3 store result score @s th.y3 run data get entity @s Pos[1]
execute if score @s th.n matches 3 store result score @s th.z3 run data get entity @s Pos[2]
execute if score @s th.n matches 3 if score @s th.dim3 matches 1 run tellraw @s {"text":"Home 3 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the Overworld. Type /trigger home set 3 to come back."}]}
execute if score @s th.n matches 3 if score @s th.dim3 matches 2 run tellraw @s {"text":"Home 3 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the Nether. Type /trigger home set 3 to come back."}]}
execute if score @s th.n matches 3 if score @s th.dim3 matches 3 run tellraw @s {"text":"Home 3 set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the End. Type /trigger home set 3 to come back."}]}
