scoreboard players set @s back 0
execute unless score @s th.deaths matches 1.. run tellraw @s {"text":"You have not died since your last /trigger back (or since this pack was added).","color":"red"}
execute unless score @s th.deaths matches 1.. run return fail
execute unless data entity @s LastDeathLocation run tellraw @s {"text":"The game has no death point for you.","color":"red"}
execute unless data entity @s LastDeathLocation run return fail
scoreboard players set @s th.tmp 0
execute if data entity @s LastDeathLocation{dimension:"minecraft:overworld"} run scoreboard players set @s th.tmp 1
execute if data entity @s LastDeathLocation{dimension:"minecraft:the_nether"} run scoreboard players set @s th.tmp 2
execute if data entity @s LastDeathLocation{dimension:"minecraft:the_end"} run scoreboard players set @s th.tmp 3
execute if score @s th.tmp matches 0 run tellraw @s {"text":"/trigger back only works for deaths in the Overworld, the Nether and the End.","color":"red"}
execute if score @s th.tmp matches 0 run return fail
execute store result score @s th.by run data get entity @s LastDeathLocation.pos[1]
execute if score @s th.tmp matches 1 if score @s th.by matches ..-65 run tellraw @s {"text":"You died below the world. /trigger back will not take you into the void.","color":"red"}
execute if score @s th.tmp matches 2 if score @s th.by matches ..-1 run tellraw @s {"text":"You died below the world. /trigger back will not take you into the void.","color":"red"}
execute if score @s th.tmp matches 3 if score @s th.by matches ..-1 run tellraw @s {"text":"You died below the world. /trigger back will not take you into the void.","color":"red"}
execute if score @s th.tmp matches 1 if score @s th.by matches ..-65 run return fail
execute if score @s th.tmp matches 2 if score @s th.by matches ..-1 run return fail
execute if score @s th.tmp matches 3 if score @s th.by matches ..-1 run return fail
execute if score @s th.cd matches 1.. run function trigger_homes:cooldown
execute if score @s th.cd matches 1.. run return fail
execute store result storage trigger_homes:tp x int 1 run data get entity @s LastDeathLocation.pos[0]
execute store result storage trigger_homes:tp y int 1 run data get entity @s LastDeathLocation.pos[1]
execute store result storage trigger_homes:tp z int 1 run data get entity @s LastDeathLocation.pos[2]
scoreboard players set @s th.by 0
execute if score @s th.tmp matches 1 in minecraft:overworld store result score @s th.by run function trigger_homes:back_tp with storage trigger_homes:tp
execute if score @s th.tmp matches 2 in minecraft:the_nether store result score @s th.by run function trigger_homes:back_tp with storage trigger_homes:tp
execute if score @s th.tmp matches 3 in minecraft:the_end store result score @s th.by run function trigger_homes:back_tp with storage trigger_homes:tp
execute unless score @s th.by matches 1 run tellraw @s {"text":"Your death point is in lava. /trigger back will not take you there.","color":"red"}
execute unless score @s th.by matches 1 run return fail
scoreboard players set @s th.deaths 0
scoreboard players set @s th.cd 600
tellraw @s {"text":"Back where you died. Pick up your things before they vanish.","color":"green"}
