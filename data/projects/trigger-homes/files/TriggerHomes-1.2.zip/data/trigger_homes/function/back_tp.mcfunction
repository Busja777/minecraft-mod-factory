$execute positioned $(x) $(y) $(z) if block ~ ~ ~ minecraft:lava run return 0
$execute positioned $(x) $(y) $(z) if block ~ ~1 ~ minecraft:lava run return 0
$tp @s $(x) $(y) $(z)
return 1
