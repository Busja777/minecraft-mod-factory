scoreboard players operation @s th.n = @s home
scoreboard players set @s home 0
execute unless score @s th.n matches 1..3 run tellraw @s {"text":"There are homes 1 to 3: /trigger home set 2 takes you to home 2.","color":"red"}
execute unless score @s th.n matches 1..3 run return fail
execute if score @s th.n matches 1 unless score @s th.dim matches 1..3 run tellraw @s {"text":"You have no home yet. Stand where you want it and type /trigger sethome.","color":"red"}
execute if score @s th.n matches 1 unless score @s th.dim matches 1..3 run return fail
execute if score @s th.n matches 2 unless score @s th.dim2 matches 1..3 run tellraw @s {"text":"You have no home 2 yet. Stand where you want it and type /trigger sethome set 2.","color":"red"}
execute if score @s th.n matches 2 unless score @s th.dim2 matches 1..3 run return fail
execute if score @s th.n matches 3 unless score @s th.dim3 matches 1..3 run tellraw @s {"text":"You have no home 3 yet. Stand where you want it and type /trigger sethome set 3.","color":"red"}
execute if score @s th.n matches 3 unless score @s th.dim3 matches 1..3 run return fail
execute if score @s th.cd matches 1.. run function trigger_homes:cooldown
execute if score @s th.cd matches 1.. run return fail
execute if score @s th.n matches 1 store result storage trigger_homes:tp x int 1 run scoreboard players get @s th.x
execute if score @s th.n matches 1 store result storage trigger_homes:tp y int 1 run scoreboard players get @s th.y
execute if score @s th.n matches 1 store result storage trigger_homes:tp z int 1 run scoreboard players get @s th.z
execute if score @s th.n matches 2 store result storage trigger_homes:tp x int 1 run scoreboard players get @s th.x2
execute if score @s th.n matches 2 store result storage trigger_homes:tp y int 1 run scoreboard players get @s th.y2
execute if score @s th.n matches 2 store result storage trigger_homes:tp z int 1 run scoreboard players get @s th.z2
execute if score @s th.n matches 3 store result storage trigger_homes:tp x int 1 run scoreboard players get @s th.x3
execute if score @s th.n matches 3 store result storage trigger_homes:tp y int 1 run scoreboard players get @s th.y3
execute if score @s th.n matches 3 store result storage trigger_homes:tp z int 1 run scoreboard players get @s th.z3
execute if score @s th.n matches 1 if score @s th.dim matches 1 in minecraft:overworld run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 1 if score @s th.dim matches 2 in minecraft:the_nether run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 1 if score @s th.dim matches 3 in minecraft:the_end run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 2 if score @s th.dim2 matches 1 in minecraft:overworld run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 2 if score @s th.dim2 matches 2 in minecraft:the_nether run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 2 if score @s th.dim2 matches 3 in minecraft:the_end run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 3 if score @s th.dim3 matches 1 in minecraft:overworld run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 3 if score @s th.dim3 matches 2 in minecraft:the_nether run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.n matches 3 if score @s th.dim3 matches 3 in minecraft:the_end run function trigger_homes:teleport with storage trigger_homes:tp
scoreboard players set @s th.cd 600
execute if score @s th.n matches 1 run tellraw @s {"text":"Welcome home.","color":"green"}
execute if score @s th.n matches 2 run tellraw @s {"text":"Welcome to home 2.","color":"green"}
execute if score @s th.n matches 3 run tellraw @s {"text":"Welcome to home 3.","color":"green"}
