scoreboard players remove @a[scores={th.cd=1..}] th.cd 1
execute as @a[scores={sethome=1..}] at @s run function trigger_homes:sethome
execute as @a[scores={home=1..}] at @s run function trigger_homes:home
execute as @a[scores={spawn=1..}] run function trigger_homes:spawn
scoreboard players set @a[scores={sethome=..-1}] sethome 0
scoreboard players set @a[scores={home=..-1}] home 0
scoreboard players set @a[scores={spawn=..-1}] spawn 0
scoreboard players enable @a sethome
scoreboard players enable @a home
scoreboard players enable @a spawn
