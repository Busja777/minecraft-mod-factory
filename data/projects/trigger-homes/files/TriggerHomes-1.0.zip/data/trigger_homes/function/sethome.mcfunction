scoreboard players set @s sethome 0
scoreboard players set @s th.tmp 0
execute if dimension minecraft:overworld run scoreboard players set @s th.tmp 1
execute if dimension minecraft:the_nether run scoreboard players set @s th.tmp 2
execute if dimension minecraft:the_end run scoreboard players set @s th.tmp 3
execute if score @s th.tmp matches 0 run tellraw @s {"text":"Homes can only be set in the Overworld, the Nether and the End.","color":"red"}
execute if score @s th.tmp matches 0 run return fail
scoreboard players operation @s th.dim = @s th.tmp
execute store result score @s th.x run data get entity @s Pos[0]
execute store result score @s th.y run data get entity @s Pos[1]
execute store result score @s th.z run data get entity @s Pos[2]
execute if score @s th.dim matches 1 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Overworld. Type /trigger home to come back."}]}
execute if score @s th.dim matches 2 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Nether. Type /trigger home to come back."}]}
execute if score @s th.dim matches 3 run tellraw @s {"text":"Home set at ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the End. Type /trigger home to come back."}]}
