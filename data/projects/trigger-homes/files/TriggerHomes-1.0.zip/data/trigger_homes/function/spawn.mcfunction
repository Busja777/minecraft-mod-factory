scoreboard players set @s spawn 0
execute if score @s th.cd matches 1.. run function trigger_homes:cooldown
execute if score @s th.cd matches 1.. run return fail
tp @s ~0.5 ~ ~0.5
scoreboard players set @s th.cd 600
tellraw @s {"text":"Teleported to the world spawn.","color":"green"}
