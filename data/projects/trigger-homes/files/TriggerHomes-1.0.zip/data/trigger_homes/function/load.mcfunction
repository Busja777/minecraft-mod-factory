scoreboard objectives add sethome trigger
scoreboard objectives add home trigger
scoreboard objectives add spawn trigger
scoreboard objectives add th.x dummy
scoreboard objectives add th.y dummy
scoreboard objectives add th.z dummy
scoreboard objectives add th.dim dummy
scoreboard objectives add th.cd dummy
scoreboard objectives add th.tmp dummy
scoreboard players set #20 th.tmp 20
