scoreboard players set @s home 0
execute unless score @s th.dim matches 1..3 run tellraw @s {"text":"You have no home yet. Stand where you want it and type /trigger sethome.","color":"red"}
execute unless score @s th.dim matches 1..3 run return fail
execute if score @s th.cd matches 1.. run function trigger_homes:cooldown
execute if score @s th.cd matches 1.. run return fail
execute store result storage trigger_homes:tp x int 1 run scoreboard players get @s th.x
execute store result storage trigger_homes:tp y int 1 run scoreboard players get @s th.y
execute store result storage trigger_homes:tp z int 1 run scoreboard players get @s th.z
execute if score @s th.dim matches 1 in minecraft:overworld run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.dim matches 2 in minecraft:the_nether run function trigger_homes:teleport with storage trigger_homes:tp
execute if score @s th.dim matches 3 in minecraft:the_end run function trigger_homes:teleport with storage trigger_homes:tp
scoreboard players set @s th.cd 600
tellraw @s {"text":"Welcome home.","color":"green"}
