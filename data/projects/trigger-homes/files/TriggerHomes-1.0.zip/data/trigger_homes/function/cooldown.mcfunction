scoreboard players operation @s th.tmp = @s th.cd
scoreboard players add @s th.tmp 19
scoreboard players operation @s th.tmp /= #20 th.tmp
tellraw @s {"text":"You can teleport again in ","color":"yellow","extra":[{"score":{"name":"@s","objective":"th.tmp"}},{"text":" s."}]}
