scoreboard players set @s homes 0
scoreboard players set @s th.tmp 0
execute if score @s th.dim matches 1..3 run scoreboard players add @s th.tmp 1
execute if score @s th.dim2 matches 1..3 run scoreboard players add @s th.tmp 1
execute if score @s th.dim3 matches 1..3 run scoreboard players add @s th.tmp 1
execute if score @s th.tmp matches 0 run tellraw @s {"text":"No homes yet. Stand where you want one and type /trigger sethome.","color":"yellow"}
execute if score @s th.tmp matches 1.. run tellraw @s {"text":"Your homes:","color":"gold"}
execute if score @s th.dim matches 1 run tellraw @s {"text":"Home 1: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Overworld (/trigger home)"}]}
execute if score @s th.dim matches 2 run tellraw @s {"text":"Home 1: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the Nether (/trigger home)"}]}
execute if score @s th.dim matches 3 run tellraw @s {"text":"Home 1: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x"}},{"text":" "},{"score":{"name":"@s","objective":"th.y"}},{"text":" "},{"score":{"name":"@s","objective":"th.z"}},{"text":" in the End (/trigger home)"}]}
execute if score @s th.dim2 matches 1 run tellraw @s {"text":"Home 2: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the Overworld (/trigger home set 2)"}]}
execute if score @s th.dim2 matches 2 run tellraw @s {"text":"Home 2: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the Nether (/trigger home set 2)"}]}
execute if score @s th.dim2 matches 3 run tellraw @s {"text":"Home 2: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x2"}},{"text":" "},{"score":{"name":"@s","objective":"th.y2"}},{"text":" "},{"score":{"name":"@s","objective":"th.z2"}},{"text":" in the End (/trigger home set 2)"}]}
execute if score @s th.dim3 matches 1 run tellraw @s {"text":"Home 3: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the Overworld (/trigger home set 3)"}]}
execute if score @s th.dim3 matches 2 run tellraw @s {"text":"Home 3: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the Nether (/trigger home set 3)"}]}
execute if score @s th.dim3 matches 3 run tellraw @s {"text":"Home 3: ","color":"green","extra":[{"score":{"name":"@s","objective":"th.x3"}},{"text":" "},{"score":{"name":"@s","objective":"th.y3"}},{"text":" "},{"score":{"name":"@s","objective":"th.z3"}},{"text":" in the End (/trigger home set 3)"}]}
execute if score @s th.cd matches 1.. run function trigger_homes:cooldown
tellraw @s {"text":"Commands: /trigger home, /trigger sethome, /trigger back, /trigger spawn. For homes 2 and 3 add set 2 or set 3, for example /trigger home set 2.","color":"gray"}
