scoreboard objectives add coords trigger
scoreboard objectives add ac.hide dummy
scoreboard objectives add ac.tmp dummy
scoreboard players set #6 ac.tmp 6
scoreboard players set #10 ac.tmp 10
scoreboard players set #24 ac.tmp 24
scoreboard players set #60 ac.tmp 60
scoreboard players set #1000 ac.tmp 1000
function actionbar_coords:update
