scoreboard players set @s coords 0
scoreboard players add @s ac.hide 1
execute if score @s ac.hide matches 2.. run scoreboard players set @s ac.hide 0
execute if score @s ac.hide matches 1 run title @s actionbar {"text":""}
execute if score @s ac.hide matches 1 run tellraw @s {"text":"Coordinates hidden. Type /trigger coords to show them again.","color":"gray"}
execute if score @s ac.hide matches 0 run tellraw @s {"text":"Coordinates shown. Type /trigger coords to hide them, /trigger coords set 2 for another colour style.","color":"gray"}
