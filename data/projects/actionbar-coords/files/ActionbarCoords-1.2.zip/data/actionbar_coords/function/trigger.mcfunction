execute if score @s coords matches 1 run function actionbar_coords:toggle
execute if score @s coords matches 2 run function actionbar_coords:style
execute if score @s coords matches 3.. run tellraw @s {"text":"Type /trigger coords to show or hide the coordinates, /trigger coords set 2 for the next colour style.","color":"gray"}
scoreboard players set @s coords 0
