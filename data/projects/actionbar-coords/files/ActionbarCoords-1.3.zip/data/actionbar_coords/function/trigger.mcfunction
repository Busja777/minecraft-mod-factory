execute if score @s coords matches 1 run function actionbar_coords:toggle
execute if score @s coords matches 2 run function actionbar_coords:style
execute if score @s coords matches 3 run function actionbar_coords:compact
execute if score @s coords matches 4.. run tellraw @s {"text":"Type /trigger coords set <number>: 1 = show or hide the line, 2 = next colour style, 3 = coordinates only on or off. /trigger coords alone is the same as 1.","color":"gray"}
scoreboard players set @s coords 0
