execute unless score @s ac.compact matches 0..1 run scoreboard players set @s ac.compact 0
scoreboard players add @s ac.compact 1
execute if score @s ac.compact matches 2.. run scoreboard players set @s ac.compact 0
execute if score @s ac.compact matches 1 run tellraw @s {"text":"Compact line: coordinates only. Type /trigger coords set 3 for the full line again.","color":"gray"}
execute if score @s ac.compact matches 0 run tellraw @s {"text":"Full line: coordinates, direction and time. Type /trigger coords set 3 for coordinates only.","color":"gray"}
execute if score @s ac.hide matches 1 run tellraw @s {"text":"The line is hidden at the moment. Type /trigger coords to show it.","color":"gray"}
