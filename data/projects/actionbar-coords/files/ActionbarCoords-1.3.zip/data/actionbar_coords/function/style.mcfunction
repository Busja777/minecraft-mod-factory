execute unless score @s ac.style matches 0..5 run scoreboard players set @s ac.style 0
scoreboard players add @s ac.style 1
execute if score @s ac.style matches 6.. run scoreboard players set @s ac.style 0
execute if score @s ac.style matches 0 run tellraw @s {"text":"Colour style: Classic (1 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
execute if score @s ac.style matches 1 run tellraw @s {"text":"Colour style: Plain (2 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
execute if score @s ac.style matches 2 run tellraw @s {"text":"Colour style: Gold (3 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
execute if score @s ac.style matches 3 run tellraw @s {"text":"Colour style: Green (4 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
execute if score @s ac.style matches 4 run tellraw @s {"text":"Colour style: Blue (5 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
execute if score @s ac.style matches 5 run tellraw @s {"text":"Colour style: Quiet (6 of 6). Type /trigger coords set 2 for the next one.","color":"gray"}
