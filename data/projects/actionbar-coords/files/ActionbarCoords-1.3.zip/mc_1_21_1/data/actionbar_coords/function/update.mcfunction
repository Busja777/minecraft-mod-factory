execute as @a[scores={coords=1..}] run function actionbar_coords:trigger
scoreboard players set @a[scores={coords=..-1}] coords 0
scoreboard players enable @a coords
execute store result score #time ac.tmp run time query daytime
scoreboard players operation #hour ac.tmp = #time ac.tmp
scoreboard players operation #hour ac.tmp /= #1000 ac.tmp
scoreboard players operation #hour ac.tmp += #6 ac.tmp
scoreboard players operation #hour ac.tmp %= #24 ac.tmp
scoreboard players operation #min ac.tmp = #time ac.tmp
scoreboard players operation #min ac.tmp %= #1000 ac.tmp
scoreboard players operation #min ac.tmp *= #60 ac.tmp
scoreboard players operation #min ac.tmp /= #1000 ac.tmp
scoreboard players operation #h10 ac.tmp = #hour ac.tmp
scoreboard players operation #h10 ac.tmp /= #10 ac.tmp
scoreboard players operation #h1 ac.tmp = #hour ac.tmp
scoreboard players operation #h1 ac.tmp %= #10 ac.tmp
scoreboard players operation #m10 ac.tmp = #min ac.tmp
scoreboard players operation #m10 ac.tmp /= #10 ac.tmp
scoreboard players operation #m1 ac.tmp = #min ac.tmp
scoreboard players operation #m1 ac.tmp %= #10 ac.tmp
execute as @a unless score @s ac.hide matches 1 run function actionbar_coords:show
schedule function actionbar_coords:update 5t replace
